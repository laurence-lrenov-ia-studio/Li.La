<?php

declare(strict_types=1);

/*
 * Relais Hostinger en lecture seule pour l'aperçu sécurisé du Hub Li.La.
 *
 * Le fichier privé attendu n'est jamais placé sous public_html :
 * dirname(__DIR__, 3) . '/private/lila-hub-secure-preview.php'
 *
 * Format attendu de ce fichier privé, sans valeurs réelles dans le projet :
 *
 * <?php
 * return [
 *     'HUB_APPS_SCRIPT_URL' => 'https://script.google.com/macros/s/DEPLOYMENT_ID/exec',
 *     'HUB_GATEWAY_SHARED_SECRET' => 'SECRET_AU_MOINS_32_CARACTERES',
 * ];
 */

const HUB_ALLOWED_ORIGIN = 'https://app.li-la.fr';
const HUB_MAX_AUTHORIZATION_LENGTH = 8192;
const HUB_MAX_UPSTREAM_BYTES = 2097152;
const HUB_CONNECT_TIMEOUT_SECONDS = 5;
const HUB_TOTAL_TIMEOUT_SECONDS = 12;
const HUB_MAX_REDIRECTS = 3;

ini_set('display_errors', '0');
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, max-age=0');
header('Pragma: no-cache');
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: no-referrer');

function hubJsonResponse(int $status, array $body, array $extraHeaders = []): never
{
    http_response_code($status);
    foreach ($extraHeaders as $name => $value) {
        header($name . ': ' . $value);
    }

    $json = json_encode(
        $body,
        JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE
    );
    if ($json === false) {
        http_response_code(503);
        $json = '{"ok":false,"error":"HUB_ACCESS_UNAVAILABLE"}';
    }

    echo $json;
    exit;
}

function hubReadAuthorizationHeader(): string
{
    if (function_exists('getallheaders')) {
        $headers = getallheaders();
        if (is_array($headers)) {
            foreach ($headers as $name => $value) {
                if (strcasecmp((string) $name, 'Authorization') === 0) {
                    return is_string($value) ? trim($value) : '';
                }
            }
        }
    }

    foreach (['HTTP_AUTHORIZATION', 'REDIRECT_HTTP_AUTHORIZATION'] as $serverKey) {
        $value = $_SERVER[$serverKey] ?? '';
        if (is_string($value) && trim($value) !== '') {
            return trim($value);
        }
    }

    return '';
}

function hubReadBearerToken(): ?string
{
    $authorization = hubReadAuthorizationHeader();
    if (
        $authorization === ''
        || strlen($authorization) > HUB_MAX_AUTHORIZATION_LENGTH
        || !preg_match(
            '/^Bearer[ \t]+([A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+)$/iD',
            $authorization,
            $matches
        )
    ) {
        return null;
    }

    $token = $matches[1];
    if (strlen($token) < 32 || strlen($token) > HUB_MAX_AUTHORIZATION_LENGTH - 7) {
        return null;
    }

    return $token;
}

function hubReadPrivateConfig(): ?array
{
    $configPath = dirname(__DIR__, 3) . '/private/lila-hub-secure-preview.php';
    if (!is_file($configPath) || !is_readable($configPath)) {
        return null;
    }

    $initialBufferLevel = ob_get_level();
    ob_start();
    try {
        $config = require $configPath;
    } catch (Throwable) {
        return null;
    } finally {
        while (ob_get_level() > $initialBufferLevel) {
            ob_end_clean();
        }
    }

    return is_array($config) ? $config : null;
}

function hubReadAppsScriptUrl(array $config): ?string
{
    $rawUrl = $config['HUB_APPS_SCRIPT_URL'] ?? '';
    if (!is_string($rawUrl)) {
        return null;
    }

    $url = trim($rawUrl);
    $parts = parse_url($url);
    if (
        $url === ''
        || !is_array($parts)
        || strtolower((string) ($parts['scheme'] ?? '')) !== 'https'
        || strtolower((string) ($parts['host'] ?? '')) !== 'script.google.com'
        || !preg_match('#^/macros/s/[A-Za-z0-9_-]+/exec$#D', (string) ($parts['path'] ?? ''))
        || isset($parts['user'])
        || isset($parts['pass'])
        || isset($parts['query'])
        || isset($parts['fragment'])
    ) {
        return null;
    }

    return $url;
}

function hubReadGatewaySecret(array $config): ?string
{
    $secret = $config['HUB_GATEWAY_SHARED_SECRET'] ?? '';
    if (!is_string($secret)) {
        return null;
    }

    $secret = trim($secret);
    return strlen($secret) >= 32 && strlen($secret) <= 4096 ? $secret : null;
}

function hubIsAllowedGoogleResponseUrl(string $url): bool
{
    $parts = parse_url($url);
    if (!is_array($parts) || strtolower((string) ($parts['scheme'] ?? '')) !== 'https') {
        return false;
    }

    $host = strtolower((string) ($parts['host'] ?? ''));
    return $host === 'script.google.com'
        || $host === 'script.googleusercontent.com'
        || str_ends_with($host, '.script.googleusercontent.com');
}

function hubContainsForbiddenAuthEmailKey(mixed $value): bool
{
    if (!is_array($value)) {
        return false;
    }

    foreach ($value as $key => $child) {
        if (is_string($key) && strtolower($key) === 'auth_email') {
            return true;
        }
        if (hubContainsForbiddenAuthEmailKey($child)) {
            return true;
        }
    }

    return false;
}

function hubMapAppsScriptError(mixed $error): never
{
    switch ($error) {
        case 'AUTH_REQUIRED':
            hubJsonResponse(401, ['ok' => false, 'error' => 'AUTH_REQUIRED']);
        case 'HUB_ACCESS_DENIED':
            hubJsonResponse(403, ['ok' => false, 'error' => 'HUB_ACCESS_DENIED']);
        case 'SUPABASE_UNREACHABLE':
            hubJsonResponse(502, ['ok' => false, 'error' => 'SUPABASE_UNREACHABLE']);
        case 'SUPABASE_RESPONSE_INVALID':
            hubJsonResponse(502, ['ok' => false, 'error' => 'SUPABASE_RESPONSE_INVALID']);
        case 'INTERNAL_ERROR':
            hubJsonResponse(500, ['ok' => false, 'error' => 'INTERNAL_ERROR']);
        case 'CONFIG_ENABLED_MISSING':
            hubJsonResponse(503, ['ok' => false, 'error' => 'CONFIG_ENABLED_MISSING']);
        case 'GATEWAY_SECRET_INVALID':
            hubJsonResponse(503, ['ok' => false, 'error' => 'GATEWAY_SECRET_INVALID']);
        case 'SUPABASE_CONFIG_INVALID':
            hubJsonResponse(503, ['ok' => false, 'error' => 'SUPABASE_CONFIG_INVALID']);
        case 'MEMBERS_SHEET_MISSING':
            hubJsonResponse(503, ['ok' => false, 'error' => 'MEMBERS_SHEET_MISSING']);
        case 'MEMBERS_HEADERS_INVALID':
            hubJsonResponse(503, ['ok' => false, 'error' => 'MEMBERS_HEADERS_INVALID']);
        default:
            hubJsonResponse(503, ['ok' => false, 'error' => 'HUB_ACCESS_UNAVAILABLE']);
    }
}

function hubFetchAppsScript(string $url, string $accessToken, string $gatewaySecret): array
{
    if (!function_exists('curl_init')) {
        throw new RuntimeException('CURL_UNAVAILABLE');
    }

    $requestBody = json_encode(
        [
            'action' => 'getSecurePreview',
            'access_token' => $accessToken,
            'gateway_secret' => $gatewaySecret,
        ],
        JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR
    );

    $responseBody = '';
    $responseTooLarge = false;
    $curl = curl_init($url);
    if ($curl === false) {
        throw new RuntimeException('CURL_UNAVAILABLE');
    }

    try {
        curl_setopt_array($curl, [
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => $requestBody,
            CURLOPT_HTTPHEADER => [
                'Content-Type: application/json; charset=utf-8',
                'Accept: application/json',
            ],
            CURLOPT_CONNECTTIMEOUT => HUB_CONNECT_TIMEOUT_SECONDS,
            CURLOPT_TIMEOUT => HUB_TOTAL_TIMEOUT_SECONDS,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_MAXREDIRS => HUB_MAX_REDIRECTS,
            CURLOPT_PROTOCOLS => CURLPROTO_HTTPS,
            CURLOPT_REDIR_PROTOCOLS => CURLPROTO_HTTPS,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
            CURLOPT_RETURNTRANSFER => false,
            CURLOPT_HEADER => false,
            CURLOPT_WRITEFUNCTION => static function ($handle, string $chunk) use (
                &$responseBody,
                &$responseTooLarge
            ): int {
                if (strlen($responseBody) + strlen($chunk) > HUB_MAX_UPSTREAM_BYTES) {
                    $responseTooLarge = true;
                    return 0;
                }
                $responseBody .= $chunk;
                return strlen($chunk);
            },
        ]);

        $success = curl_exec($curl);
        $status = (int) curl_getinfo($curl, CURLINFO_RESPONSE_CODE);
        $effectiveUrl = (string) curl_getinfo($curl, CURLINFO_EFFECTIVE_URL);
    } finally {
        curl_close($curl);
    }

    if (
        $success !== true
        || $responseTooLarge
        || $status < 200
        || $status >= 300
        || $responseBody === ''
        || !hubIsAllowedGoogleResponseUrl($effectiveUrl)
    ) {
        throw new RuntimeException('UPSTREAM_UNAVAILABLE');
    }

    try {
        $payload = json_decode($responseBody, true, 64, JSON_THROW_ON_ERROR);
    } catch (JsonException) {
        throw new RuntimeException('UPSTREAM_INVALID_JSON');
    }

    if (!is_array($payload)) {
        throw new RuntimeException('UPSTREAM_INVALID_JSON');
    }

    return $payload;
}

try {
    if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
        hubJsonResponse(
            405,
            ['ok' => false, 'error' => 'METHOD_NOT_ALLOWED'],
            ['Allow' => 'POST']
        );
    }

    if (($_SERVER['HTTP_ORIGIN'] ?? '') !== HUB_ALLOWED_ORIGIN) {
        hubJsonResponse(403, ['ok' => false, 'error' => 'FORBIDDEN']);
    }

    $accessToken = hubReadBearerToken();
    if ($accessToken === null) {
        hubJsonResponse(401, ['ok' => false, 'error' => 'AUTH_REQUIRED']);
    }

    $config = hubReadPrivateConfig();
    if ($config === null) {
        hubJsonResponse(503, ['ok' => false, 'error' => 'HUB_ACCESS_UNAVAILABLE']);
    }

    $appsScriptUrl = hubReadAppsScriptUrl($config);
    $gatewaySecret = hubReadGatewaySecret($config);
    if ($appsScriptUrl === null || $gatewaySecret === null) {
        hubJsonResponse(503, ['ok' => false, 'error' => 'HUB_ACCESS_UNAVAILABLE']);
    }

    $payload = hubFetchAppsScript($appsScriptUrl, $accessToken, $gatewaySecret);
    if (($payload['ok'] ?? null) !== true) {
        hubMapAppsScriptError($payload['error'] ?? null);
    }

    if (hubContainsForbiddenAuthEmailKey($payload)) {
        hubJsonResponse(503, ['ok' => false, 'error' => 'HUB_ACCESS_UNAVAILABLE']);
    }

    hubJsonResponse(200, $payload);
} catch (Throwable) {
    hubJsonResponse(503, ['ok' => false, 'error' => 'HUB_ACCESS_UNAVAILABLE']);
}
